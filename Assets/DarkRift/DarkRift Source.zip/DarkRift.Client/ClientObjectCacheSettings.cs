﻿namespace DarkRift.Client
{
    /// <summary>
    ///     Configuration for the <see cref="ClientObjectCache"/>.
    /// </summary>
    public class ClientObjectCacheSettings : ObjectCacheSettings
    {
        /// <summary>
        ///     Return settings so no objects are cached.
        /// </summary>
        public static new ClientObjectCacheSettings DontUseCache { get; } = new ClientObjectCacheSettings();

        /// <summary>
        ///     The maximum number of MessageReceivedEventArgs to cache per thread.
        /// </summary>
        public int MaxMessageReceivedEventArgs { get; set; }
    }
}
