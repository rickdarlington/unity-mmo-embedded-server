﻿namespace DarkRift.Dispatching
{
    /// <summary>
    ///     Delegate used when a dispatch call has completed.
    /// </summary>
    /// <param name="task">The task that was completed.</param>
    public delegate void ActionDispatchCompleteCallback(ActionDispatcherTask task);
}
