# Groups Element
The `<groups>` element informs the server of the system's architecture.

## Attributes
There are no attributes for this element.

## Child Elements
- groups
