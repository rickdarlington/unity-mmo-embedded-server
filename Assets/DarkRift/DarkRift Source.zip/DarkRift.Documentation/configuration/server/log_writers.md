# Log Writers Element
`<logWriters>` element is used to specify the log writers to load into the server.

## Attributes
There are no attributes for this element.

## Child Elements
- logWriter
