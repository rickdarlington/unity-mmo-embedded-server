# Metrics Writer Element
`<metricsWriter>` element is used to specify a metrics writer to be loaded into the server.

## Attributes
| Attribute | Values | Description |
|-----------|--------|-------------|
| type (required) |  | The name of the metrics writer type to instantiate. |

## Child Elements
- settings
