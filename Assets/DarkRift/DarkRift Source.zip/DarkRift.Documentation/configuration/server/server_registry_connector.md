# ServerRegsitryConnector Element
`<serverRegistryConnector>` element specifies a server registry connector to be loaded.

## Attributes
| Attribute | Values | Description |
|-----------|--------|-------------|
| type |  | The name of the plugin type to instantiate. |

## Child Elements
- settings
