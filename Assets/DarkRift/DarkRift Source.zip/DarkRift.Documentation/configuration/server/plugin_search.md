# Plugin Search Element
The `<pluginSearch>` element informs the server where plugins may be found on the filesystem to be later loaded.

## Attributes
There are no attributes for this element.

## Child Elements
- pluginSearchPath
