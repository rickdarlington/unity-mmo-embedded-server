# Object Cache Monitor
The `ObjectCacheMonitor` outputs warnings when objects are not being recycled correctly.

## Settings
The following settings are exposed to configuration:

| Setting   | Default | Description |
|-----------|---------|-------------|
| `period` | `10000` | The period between checks, in milliseconds. |
