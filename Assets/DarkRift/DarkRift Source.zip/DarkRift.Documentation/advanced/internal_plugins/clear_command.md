# Clear Command
The `ClearCommand` is a simple command that clears the console window.

## Commands
The following commands are exposed:

| Command   | Usage | Description |
|-----------|-------|-------------|
| `clear` | `clear` | Clears the console window. |
