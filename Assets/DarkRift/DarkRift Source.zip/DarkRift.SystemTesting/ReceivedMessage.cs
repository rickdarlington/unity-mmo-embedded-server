﻿namespace DarkRift.SystemTesting
{
    /// <summary>
    ///     Holder for messages.
    /// </summary>
    public struct ReceivedMessage
    {
        public string Message { get; set; }
        public ushort Source { get; set; }
        public ushort Destination { get; set; }
        public ushort Tag { get; set; }
        public SendMode SendMode { get; set; }

        public ReceivedMessage(string message, ushort source, ushort destination, ushort tag, SendMode sendMode)
        {
            this.Message = message;
            this.Source = source;
            this.Destination = destination;
            this.Tag = tag;
            this.SendMode = sendMode;
        }
    }
}
