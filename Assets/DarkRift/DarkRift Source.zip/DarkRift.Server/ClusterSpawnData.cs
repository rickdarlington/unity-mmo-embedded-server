﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Xml.Linq;

namespace DarkRift.Server
{
#if PRO
    /// <summary>
    ///     Details of the architecture of the cluster.
    /// </summary>
    [Serializable]
    public class ClusterSpawnData
    {
        /// <summary>
        ///     Holds the groups in the cluster.
        /// </summary>
        public GroupsSettings Groups { get; set; } = new GroupsSettings();

        /// <summary>
        ///     Details the groups in the cluster.
        /// </summary>
        [Serializable]
        public class GroupsSettings
        {
            /// <summary>
            ///     The groups in the cluster.
            /// </summary>
            public List<GroupSettings> Groups { get; } = new List<GroupSettings>();

            /// <summary>
            ///     Details of a group in the cluster
            /// </summary>
            [Serializable]
            public class GroupSettings
            {
                /// <summary>
                ///     The name of the group.
                /// </summary>
                public string Name { get; set; }

                /// <summary>
                ///     Whether the server is external facing or internal facing.
                /// </summary>
                public ServerVisibility Visibility { get; set; }

                /// <summary>
                ///     The groups this group connects to.
                /// </summary>
                public List<ConnectsToSettings> ConnectsTo { get; } = new List<ConnectsToSettings>();

                /// <summary>
                ///     Holds details about server links.
                /// </summary>
                [Serializable]
                public class ConnectsToSettings
                {
                    /// <summary>
                    ///     The name of the group to connect to.
                    /// </summary>
                    public string Name { get; set; }

                    /// <summary>
                    ///     Loads the groups settings from the specified XML element.
                    /// </summary>
                    /// <param name="element">The XML element to load from.</param>
                    /// <param name="helper">The XML configuration helper being used.</param>
                    internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
                    {
                        if (element == null || element.Name != "connectsTo")
                            throw new XmlConfigurationException("ConnectTo settings must be contained in a <connectTo> element.");

                        Name = helper.ReadStringAttribute(
                            element,
                            "name",
                            "<connectTo> elements must contain a name attribute."
                        );
                    }
                }

                /// <summary>
                ///     Constructor for a new group settings instance with null values.
                /// </summary>
                public GroupSettings()
                {

                }

                /// <summary>
                ///     Constructor for a new group settings instance.
                /// </summary>
                /// <param name="name">The group name.</param>
                /// <param name="visibility">The group's visibility.</param>
                public GroupSettings(string name, ServerVisibility visibility)
                {
                    this.Name = name;
                    this.Visibility = visibility;
                }

                /// <summary>
                ///     Loads the groups settings from the specified XML element.
                /// </summary>
                /// <param name="element">The XML element to load from.</param>
                /// <param name="helper">The XML configuration helper being used.</param>
                internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
                {
                    if (element == null || element.Name != "group")
                        throw new XmlConfigurationException("Group settings must be contained in a <group> element.");

                    Name = helper.ReadStringAttribute(
                        element,
                        "name",
                        "<group> elements must contain a name attribute."
                    );

                    Visibility = helper.ReadServerVisibilityAttribute(
                        element,
                        "visibility",
                        "<group> elements must contain a visibility attribute.",
                        "<group> visibility attribute not a valid server visibility."
                    );

                    helper.ReadElementCollectionTo(
                        element,
                        "connectsTo",
                        e => {
                            ConnectsToSettings s = new ConnectsToSettings();
                            s.LoadFromXmlElement(e, helper);
                            return s;
                        },
                        ConnectsTo
                    );
                }
            }

            /// <summary>
            ///     Loads the groups settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "groups")
                    throw new XmlConfigurationException("Groups settings must be contained in a <groups> element.");

                helper.ReadElementCollectionTo(
                    element,
                    "group",
                    e => {
                        GroupSettings s = new GroupSettings();
                        s.LoadFromXmlElement(e, helper);
                        return s;
                    },
                    Groups
                );
            }
        }

        /// <summary>
        ///     Creates a cluster spawn data from specified XML configuration file.
        /// </summary>
        /// <param name="filePath">The path of the XML file.</param>
        /// <param name="variables">The variables to inject into the configuration.</param>
        /// <returns>The ClusterSpawnData created.</returns>
        public static ClusterSpawnData CreateFromXml(string filePath, NameValueCollection variables)
        {
            return CreateFromXml(XDocument.Load(filePath), variables);
        }

        /// <summary>
        ///     Creates a cluster spawn data from specified XML configuration file.
        /// </summary>
        /// <param name="document">The XML file.</param>
        /// <param name="variables">The variables to inject into the configuration.</param>
        /// <returns>The ClusterSpawnData created.</returns>
        public static ClusterSpawnData CreateFromXml(XDocument document, NameValueCollection variables)
        {
            //Create a new cluster spawn data.
            ClusterSpawnData spawnData = new ClusterSpawnData();

            ConfigurationFileHelper helper = new ConfigurationFileHelper(variables);

            XElement root = document.Root;

            spawnData.Groups.LoadFromXmlElement(root.Element("groups"), helper);

            //Return the new spawn data!
            return spawnData;
        }

        /// <summary>
        ///     Creates a new cluster spawn data with necessary settings.
        /// </summary>
        public ClusterSpawnData()
        {
        }

        /// <summary>
        ///     Creates a cluster with a single, default group
        /// </summary>
        /// <returns>A new default cluster.</returns>
        internal static ClusterSpawnData CreateDefault()
        {
            return new ClusterSpawnData();
        }
    }
#endif
}
