﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    /// <summary>
    ///     Help command!
    /// </summary>
    internal sealed class HelpCommand : Plugin
    {
        public override Version Version => new Version(1, 0, 0);

        public override bool ThreadSafe => true;

        internal override bool Hidden => true;

        public override Command[] Commands => new Command[]
        {
            new Command("help", "Retrieves the documentation for a specified command.", "help <command>\nhelp -l|-l=<plugin-name>", Help)
        };

        public HelpCommand(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {
        }

        private void Help(object sender, CommandEventArgs e)
        {
            if (e.RawArguments.Length == 1)
            {
                Command command;
                try
                {
                    command = Server.CommandEngine.FindCommand(e.RawArguments[0]);
                }
                catch (Exception exception)
                {
                    Logger.Error(exception.Message);

                    return;
                }

                Logger.Info($"Command: \"{command.Name}\"\n\nUsage:\n{command.Usage}\n\nDescription:\n{command.Description}");
            }
            else if (e.HasFlag("l"))
            {
                IEnumerable<Command> commands;
                if (e.Flags["l"] != null)
                {
                    try
                    {
                        commands = Server.CommandEngine.GetCommands(e.Flags["l"]);
                    }
                    catch (KeyNotFoundException)
                    {
                        Logger.Error("No plugins found with the name '" + e.Flags["l"] + "'");

                        return;
                    }
                }
                else
                {
                    commands = Server.CommandEngine.GetCommands();
                }

                Logger.Info(commands.Count() == 0 ? "This plugin has no commands." : string.Join(", ", commands.Select(c => c.Name).ToArray()));
            }
            else
            {
                throw new CommandSyntaxException();
            }
        }
    }
}
