﻿using DarkRift.Server.Metrics;
using System.Security.Cryptography;
using System.Threading;

namespace DarkRift.Server.Plugins.Metrics.Prometheus
{
#if PRO
    /// <summary>
    /// Implementation of <see cref="IGaugeMetric"/> for Prometheus.
    /// </summary>
    internal class GaugeMetric : IGaugeMetric
    {
        /// <inheritDoc/>
        internal string Name { get; }

        /// <inheritDoc/>
        internal string Description { get; }

        /// <summary>
        /// The current gauge value.
        /// </summary>
        internal double Value => InterlockedDouble.Read(ref value);

        /// <summary>
        /// The timestamp the counter was last updated.
        /// </summary>
        internal long Timestamp => Interlocked.Read(ref timestamp);

        /// <summary>
        ///     The preformatted metric text.
        /// </summary>
        internal string Preformatted { get; }

        /// <summary>
        ///     The current counter value.
        /// </summary>
        private double value;

        /// <summary>
        /// The timestamp the counter was last updated.
        /// </summary>
        private long timestamp;

        public GaugeMetric(string name, string description, string preformatted)
        {
            this.Name = name;
            this.Description = description;
            this.Preformatted = preformatted;
            this.timestamp = PrometheusEndpoint.GetTimestamp();
        }

        /// <inheritDoc/>
        public void Report(double value)
        {
            Interlocked.Exchange(ref this.value, value);
            Interlocked.Exchange(ref this.timestamp, PrometheusEndpoint.GetTimestamp());
        }
    }
#endif
}
