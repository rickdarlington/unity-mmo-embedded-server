﻿namespace DarkRift.Server.Metrics
{
#if PRO
    /// <summary>
    /// A metric measuring a statistical disribution of values.
    /// </summary>
    /// <remarks>
    ///     Pro only.
    /// </remarks>
    public interface IHistogramMetric
    {
        /// <summary>
        /// Adds the value to the histogram.
        /// </summary>
        /// <param name="value">The value to add.</param>
        void Report(double value);
    }
#endif
}
