﻿namespace DarkRift.Server.Metrics
{
#if PRO
    /// <summary>
    /// Implementation of <see cref="IGaugeMetric"/> that does nothing.
    /// </summary>
    /// <remarks>
    ///     Pro only.
    /// </remarks>
    internal class NoOpGaugeMetric : IGaugeMetric
    {
        public void Report(double value)
        {
            // Nope
        }
    }
#endif
}
