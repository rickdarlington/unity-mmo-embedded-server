﻿namespace DarkRift.Server.Metrics
{
#if PRO
    /// <summary>
    /// Implementation of <see cref="IHistogramMetric"/> that does nothing.
    /// </summary>
    /// <remarks>
    ///     Pro only.
    /// </remarks>
    internal class NoOpHistogramMetric : IHistogramMetric
    {
        public void Report(double value)
        {
            // Nope
        }
    }
#endif
}
