﻿namespace DarkRift.Server
{
#if PRO
    /// <summary>
    ///     The direction of a connection to another server.
    /// </summary>
    public enum ServerConnectionDirection
    {
        /// <summary>
        ///     Indicates we connect to the remote server.
        /// </summary>
        Upstream,

        /// <summary>
        ///     Indicates the remote server connects to us.
        /// </summary>
        Downstream
    }
#endif
}
