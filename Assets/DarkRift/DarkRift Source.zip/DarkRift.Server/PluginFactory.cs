﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace DarkRift.Server
{
    /// <summary>
    ///     Factory for creating plugins of various types.
    /// </summary>
    internal sealed class PluginFactory
    {
        /// <summary>
        ///     The list of types that can be loaded.
        /// </summary>
        private readonly Dictionary<string, Type> types = new Dictionary<string, Type>();

        /// <summary>
        ///     The logger this factory will use.
        /// </summary>
        private readonly Logger logger;

        /// <summary>
        ///     Creates a new PluginFactory.
        /// </summary>
        /// <param name="logger">The logger this factory will use.</param>
        internal PluginFactory(Logger logger)
        {
            this.logger = logger;
        }

        /// <summary>
        ///     Adds plugins based on the plugins settings supplied.
        /// </summary>
        /// <param name="settings">The settings defining where to find plugins.</param>
        internal void AddFromSettings(ServerSpawnData.PluginSearchSettings settings)
        {
            AddTypes(settings.PluginTypes);

            foreach (ServerSpawnData.PluginSearchSettings.PluginSearchPath path in settings.PluginSearchPaths)
            {
                if (File.Exists(path.Source))
                    AddFile(path.Source);
                else
                    AddDirectory(path.Source, path.CreateDirectory);
            }
        }

        /// <summary>
        ///     Adds a directory of plugin files to the index.
        /// </summary>
        /// <param name="directory">The directory to add.</param>
        /// <param name="create">Whether to create the directory if not present.</param>
        internal void AddDirectory(string directory, bool create)
        {
            //Create plugin directory if not present
            if (Directory.Exists(directory))
            {
                //Get the names of all files to try and load
                string[] pluginSourceFiles = Directory.GetFiles(directory, "*.dll", SearchOption.AllDirectories);

                AddFiles(pluginSourceFiles);
            }
            else
            {
                if (create)
                    Directory.CreateDirectory(directory);
            }
        }

        /// <summary>
        ///     Adds the given plugin files into the index.
        /// </summary>
        /// <param name="files">An array of filepaths to the plugins.</param>
        internal void AddFiles(IEnumerable<string> files)
        {
            //Load each file to a plugin
            foreach (string pluginSourceFile in files)
                AddFile(pluginSourceFile);
        }

        /// <summary>
        ///     Adds plugins into the server from the given types.
        /// </summary>
        /// <param name="pluginTypes">The types of plugins to add.</param>
        internal void AddTypes(IEnumerable<Type> pluginTypes)
        {
            foreach (Type pluginType in pluginTypes)
                AddType(pluginType);
        }

        /// <summary>
        ///     Adds all plugin types in the file to the index.
        /// </summary>
        /// <param name="file">The file containing the types.</param>
        internal void AddFile(string file)
        {
            //Check the file is a dll
            if (Path.GetExtension(file) != ".dll")
                throw new ArgumentException("The filepath supplied was not a DLL library.");

            //Check the file exists
            if (!File.Exists(file))
                throw new FileNotFoundException("The specified filepath does not exist.");

            //Log
            logger.Trace($"Searching '{file}' for plugins.");

            // Setup assembly resolver to help find dependencies recursively in the folder heirachy of the plugin
            AppDomain.CurrentDomain.AssemblyResolve += LoadFromSameFolder;

            Assembly LoadFromSameFolder(object sender, ResolveEventArgs args)
            {
                string rootFolderPath = Path.GetDirectoryName(file);
                string assemblyPath = SearchForFile(rootFolderPath, new AssemblyName(args.Name).Name + ".dll");
                if (assemblyPath == null)
                    return null;

                return Assembly.LoadFrom(assemblyPath);
            }

            //Load the assembly
            Assembly assembly;
            try
            {
                assembly = Assembly.LoadFrom(Path.GetFullPath(file));
            }
            catch (Exception e)
            {
                logger.Error($"{file} could not be loaded as an exception occurred.", e);
                return;
            }

            //Get the types in the assembly
            IEnumerable<Type> enclosedTypes;
            try
            {
                enclosedTypes = assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException e)
            {
                logger.Error(
                    $"Failed to load one or more plugins from DLL file '{file}', see info level for exception and more info. Rebuilding plugin may help.",
                    e
                );

                foreach (Exception loaderException in e.LoaderExceptions)
                {
                    logger.Info("Additional exception detail from LoaderExceptions property.", loaderException);
                }

                // The types unable to be loaded will be null here!
                enclosedTypes = e.Types.Where(t => t != null);
            }

            //Find the types that are plugins
            foreach (Type enclosedType in enclosedTypes)
            {
                if (enclosedType.IsSubclassOf(typeof(PluginBase)) && !enclosedType.IsAbstract)
                {
                    //Add the plugin
                    AddType(enclosedType);
                }
            }

            // Remove resolver again
            AppDomain.CurrentDomain.AssemblyResolve -= LoadFromSameFolder;
        }

        /// <summary>
        ///     Adds a type to the lookup.
        /// </summary>
        /// <param name="plugin">The plugin type to add.</param>
        internal void AddType(Type plugin)
        {
            if (!plugin.IsSubclassOf(typeof(PluginBase)))
                throw new ArgumentException("The type supplied was not a plugin!");

            if (plugin.IsAbstract)
                throw new ArgumentException("Cannot create an instance of an abstract type.");

            // Add if it has not already been added (and warn if two different types with the same name are added)
            if (!types.ContainsKey(plugin.Name))
                types.Add(plugin.Name, plugin);
            else if (types[plugin.Name] != plugin)
                logger.Error("A plugin named " + plugin.Name + " could not be added to the factory as it was already present. You have two plugins with the same name.");
        }

        /// <summary>
        ///     Creates a named type as a specified plugin.
        /// </summary>
        /// <typeparam name="T">The type of plugin to load it as.</typeparam>
        /// <param name="type">The name of the type to load.</param>
        /// <param name="loadData">The data to load into the plugin.</param>
        /// <param name="backupLoadData">The backup load data to try for backwards compatablity.</param>
        /// <returns>The new plugin.</returns>
        internal T Create<T>(string type, PluginBaseLoadData loadData, PluginLoadData backupLoadData = null) where T : PluginBase
        {
            return Create<T>(types[type], loadData, backupLoadData);
        }

        /// <summary>
        ///     Creates a type as a specified plugin.
        /// </summary>
        /// <typeparam name="T">The type of plugin to load it as.</typeparam>
        /// <param name="type">The type to load.</param>
        /// <param name="loadData">The data to load into the plugin.</param>
        /// <param name="backupLoadData">The backup load data to try for backwards compatability.</param>
        /// <returns>The new plugin.</returns>
        internal T Create<T>(Type type, PluginBaseLoadData loadData, PluginLoadData backupLoadData = null) where T : PluginBase
        {
            //Create an instance of the plugin
            T plugin;
            try
            {
                plugin = (T)Activator.CreateInstance(type, loadData);
            }
            catch (MissingMethodException)
            {
                //Failed, perhaps using backup PluginLoadData would help?
                if (backupLoadData != null)
                {
                    plugin = (T)Activator.CreateInstance(type, backupLoadData);
                    logger.Warning("Reverted to loading plugin with backup PluginLoadData object, ensure this plugin has a constructor accepting a " + loadData.GetType().Name + ".");
                }
                else
                {
                    throw;
                }
            }

            //Log creation
            if (!plugin.Hidden)
                logger.Trace($"Created plugin '{type.Name}'.");
            
            return plugin;
        }

        /// <summary>
        ///     Returns a list of plugins found that are subtypes of that given.
        /// </summary>
        /// <param name="type">The type to filter by.</param>
        /// <returns>The types found.</returns>
        internal Type[] GetAllSubtypes(Type type)
        {
            return types.Values
                .Where(t => t.IsSubclassOf(type))
                .ToArray();
        }

        private string SearchForFile(string rootDirectory, string fileName)
        {
            // Try and find the file in this directory
            string filePath = Path.Combine(rootDirectory, fileName);
            if (File.Exists(filePath))
                return filePath;

            // If it's not there look in the subdirectories
            foreach (string subdirectory in Directory.GetDirectories(rootDirectory))
            {
                string found = SearchForFile(rootDirectory, fileName);
                if (found != null)
                    return found;
            }

            // Otherwise it doesn't exist
            return null;
        }
    }
}
