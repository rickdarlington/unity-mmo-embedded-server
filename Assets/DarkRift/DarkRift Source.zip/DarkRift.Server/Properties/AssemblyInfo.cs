﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("DarkRift.Server.Testing")]