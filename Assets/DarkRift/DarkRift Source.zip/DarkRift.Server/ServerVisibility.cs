﻿namespace DarkRift.Server
{
#if PRO
    /// <summary>
    ///     The visibility of the server.
    /// </summary>
    public enum ServerVisibility
    {
        /// <summary>
        ///     Indicates this server can only be connected to by clients.
        /// </summary>
        External,

        /// <summary>
        ///     Indicates this server can only be connected to by other servers.
        /// </summary>
        Internal
    }
#endif
}
